package com.example.libraryclient.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/** Адрес сервиса «Библиотека». Начальное значение из application.properties, менять можно на странице. */
@Component
public class ApiSettings {

    private volatile String baseUrl;

    public ApiSettings(@Value("${library.api.base-url}") String initial) {
        this.baseUrl = normalize(initial);
    }

    public String getBaseUrl() {
        return baseUrl;
    }

    public void setBaseUrl(String baseUrl) {
        this.baseUrl = normalize(baseUrl);
    }

    public static String normalize(String url) {
        return url == null ? "" : url.trim().replaceAll("/+$", "");
    }
}
