package com.example.libraryclient.web;

import com.example.libraryclient.api.ApiException;
import com.example.libraryclient.api.LibraryApiClient;
import com.example.libraryclient.config.ApiSettings;
import com.example.libraryclient.dto.BookDto;
import com.example.libraryclient.dto.LibraryDto;
import com.example.libraryclient.dto.OrderDto;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/** Главная страница читателя: токены, каталог с поиском, «Мои заказы». */
@Controller
public class HomeController {

    private static final Map<String, String> STATUS_TEXT = Map.of(
            "NEW", "Забронирована", "ISSUED", "На руках", "RETURNED", "Возвращена", "CANCELLED", "Отменена");
    private static final Map<String, String> STATUS_CLASS = Map.of(
            "NEW", "st-new", "ISSUED", "st-issued", "RETURNED", "st-done", "CANCELLED", "st-cancel");

    private final LibraryApiClient api;
    private final ApiSettings settings;

    public HomeController(LibraryApiClient api, ApiSettings settings) {
        this.api = api;
        this.settings = settings;
    }

    @GetMapping("/")
    public String home(@RequestParam(name = "title", defaultValue = "") String title,
                       @RequestParam(name = "author", defaultValue = "") String author,
                       @RequestParam(name = "genre", defaultValue = "") String genre,
                       HttpSession session, Model model) {

        String catalogToken = SessionTokens.get(session, SessionTokens.CATALOG);
        String ordersToken = SessionTokens.get(session, SessionTokens.ORDERS);

        model.addAttribute("catalogToken", catalogToken);
        model.addAttribute("ordersToken", ordersToken);
        model.addAttribute("hasCatalogToken", !catalogToken.isEmpty());
        model.addAttribute("hasOrdersToken", !ordersToken.isEmpty());
        model.addAttribute("qTitle", title);
        model.addAttribute("qAuthor", author);
        model.addAttribute("qGenre", genre);
        model.addAttribute("serviceUrl", settings.getBaseUrl());
        model.addAttribute("today", LocalDate.now().toString());
        model.addAttribute("statusText", STATUS_TEXT);
        model.addAttribute("statusClass", STATUS_CLASS);

        // ---- каталог ----
        List<BookDto> books = List.of();
        Map<Long, String> meta = new HashMap<>();
        Map<Long, String> bookTitles = new HashMap<>();
        String catalogError = null;
        if (!catalogToken.isEmpty()) {
            try {
                books = api.books(catalogToken, title, author, genre);
                Map<Long, String> libraries = api.libraries(catalogToken).stream()
                        .collect(Collectors.toMap(LibraryDto::id, LibraryDto::name, (a, b) -> a));
                for (BookDto b : books) {
                    meta.put(b.id(), Stream.of(b.genre(), b.year() == null ? null : b.year().toString(),
                                    libraries.get(b.libraryId()))
                            .filter(s -> s != null && !s.isBlank())
                            .collect(Collectors.joining(" · ")));
                }
                // для названий книг в списке заказов нужен весь каталог
                boolean filtered = !(title + author + genre).isBlank();
                List<BookDto> all = filtered ? api.books(catalogToken, "", "", "") : books;
                all.forEach(b -> bookTitles.put(b.id(), b.title() + " - " + b.author()));
            } catch (ApiException e) {
                catalogError = e.getMessage();
            }
        }
        model.addAttribute("books", books);
        model.addAttribute("meta", meta);
        model.addAttribute("catalogError", catalogError);

        // ---- мои заказы ----
        List<OrderDto> orders = List.of();
        Map<Long, String> orderTitle = new HashMap<>();
        String ordersError = null;
        if (!ordersToken.isEmpty()) {
            try {
                orders = new ArrayList<>(api.orders(ordersToken));
                orders.sort(Comparator.comparing(OrderDto::id).reversed());
                for (OrderDto o : orders) {
                    orderTitle.put(o.id(), bookTitles.getOrDefault(o.bookId(), "Книга №" + o.bookId()));
                }
            } catch (ApiException e) {
                ordersError = e.getMessage();
            }
        }
        model.addAttribute("orders", orders);
        model.addAttribute("orderTitle", orderTitle);
        model.addAttribute("ordersError", ordersError);
        model.addAttribute("ordersOwner", ordersToken.isEmpty() ? "" : SessionTokens.shortToken(ordersToken));

        return "index";
    }

    /** Сохранить (или удалить, если пусто) токен метода. back - страница, на которую вернуться. */
    @PostMapping("/tokens")
    public String saveToken(@RequestParam("method") String method,
                            @RequestParam(name = "token", defaultValue = "") String token,
                            @RequestParam(name = "back", defaultValue = "/") String back,
                            HttpSession session, RedirectAttributes ra) {
        if (!SessionTokens.isMethod(method)) {
            flash(ra, "error", "Неизвестный метод: " + method);
        } else {
            SessionTokens.set(session, method, token);
            flash(ra, "ok", token.isBlank() ? "Токен удалён" : "Токен сохранён");
        }
        return "redirect:" + ("/admin".equals(back) ? "/admin" : "/");
    }

    /** Смена адреса сервиса: сохраняется, только если по новому адресу сервис отвечает. */
    @PostMapping("/connection")
    public String connection(@RequestParam("url") String url, RedirectAttributes ra) {
        String normalized = ApiSettings.normalize(url);
        if (!normalized.matches("https?://.+")) {
            flash(ra, "error", "Адрес должен начинаться с http:// и содержать порт, например http://10.160.107.212:8081");
        } else if (api.ping(normalized)) {
            settings.setBaseUrl(normalized);
            flash(ra, "ok", "Сервис доступен: " + normalized + ". Адрес сохранён.");
        } else {
            flash(ra, "error", "Нет связи с " + normalized + ". Проверьте адрес и порт, что сервис запущен, "
                    + "что вы в одной сети и порт открыт в файрволе.");
        }
        return "redirect:/";
    }

    static void flash(RedirectAttributes ra, String type, String message) {
        ra.addFlashAttribute("flashType", type);
        ra.addFlashAttribute("flash", message);
    }
}
