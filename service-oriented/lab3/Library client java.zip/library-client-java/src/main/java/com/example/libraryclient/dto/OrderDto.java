package com.example.libraryclient.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/** Заказ. Даты - строки (orderDate "2026-10-19T14:30:00", returnDate "2026-11-15"). */
@JsonIgnoreProperties(ignoreUnknown = true)
public record OrderDto(Long id, Long bookId, String readerName, String readerPhone,
                       String orderDate, String returnDate, String status) {
}
