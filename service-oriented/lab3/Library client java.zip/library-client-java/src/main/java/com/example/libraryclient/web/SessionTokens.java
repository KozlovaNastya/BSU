package com.example.libraryclient.web;

import jakarta.servlet.http.HttpSession;

/**
 * Токены оплаты хранятся в сессии браузера: по одному на каждый платный метод.
 * Токен метода "orders" = личный кабинет читателя: его заказы лежат на сервисе, привязанные к этому токену.
 */
public final class SessionTokens {

    public static final String CATALOG = "catalog";
    public static final String ORDERS = "orders";

    private SessionTokens() {
    }

    public static boolean isMethod(String method) {
        return CATALOG.equals(method) || ORDERS.equals(method);
    }

    public static String get(HttpSession session, String method) {
        Object value = session.getAttribute("token." + method);
        return value == null ? "" : value.toString();
    }

    public static void set(HttpSession session, String method, String token) {
        if (token == null || token.isBlank()) {
            session.removeAttribute("token." + method);
        } else {
            session.setAttribute("token." + method, token.trim());
        }
    }

    public static String shortToken(String token) {
        return token.length() > 8 ? "…" + token.substring(token.length() - 6) : token;
    }

    /** Имя и телефон читателя запоминаются в сессии, чтобы не вводить при каждом заказе. */
    public static String profile(HttpSession session, String field) {
        Object value = session.getAttribute("profile." + field);
        return value == null ? "" : value.toString();
    }

    public static void saveProfile(HttpSession session, String name, String phone) {
        session.setAttribute("profile.name", name == null ? "" : name);
        session.setAttribute("profile.phone", phone == null ? "" : phone);
    }
}
