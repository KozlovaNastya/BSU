package com.example.libraryclient.dto;

/** Тело запроса на создание / изменение книги. */
public record BookRequest(Long libraryId, String title, String author, String genre,
                          String isbn, Integer year, Integer copiesAvailable) {
}
