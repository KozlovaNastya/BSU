package com.example.libraryclient.web;

import java.util.Map;

/** Разбор полей HTML-форм. Ошибки ввода - IllegalArgumentException с понятным текстом. */
final class Forms {

    private Forms() {
    }

    static String text(Map<String, String> p, String key) {
        String v = p.get(key);
        return v == null ? "" : v.trim();
    }

    static String textOrNull(Map<String, String> p, String key) {
        String v = text(p, key);
        return v.isEmpty() ? null : v;
    }

    static String required(Map<String, String> p, String key, String label) {
        String v = text(p, key);
        if (v.isEmpty()) {
            throw new IllegalArgumentException("Заполните поле «" + label + "»");
        }
        return v;
    }

    static Long requiredLong(Map<String, String> p, String key, String label) {
        String v = required(p, key, label);
        try {
            return Long.valueOf(v);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Поле «" + label + "» должно быть числом");
        }
    }

    static Integer intOrNull(Map<String, String> p, String key, String label) {
        String v = text(p, key);
        if (v.isEmpty()) return null;
        try {
            return Integer.valueOf(v);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Поле «" + label + "» должно быть целым числом");
        }
    }
}
