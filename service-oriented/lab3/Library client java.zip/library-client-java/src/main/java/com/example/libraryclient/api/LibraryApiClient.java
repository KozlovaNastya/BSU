package com.example.libraryclient.api;

import com.example.libraryclient.config.ApiSettings;
import com.example.libraryclient.dto.*;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestClientResponseException;

import java.net.http.HttpClient;
import java.time.Duration;
import java.util.List;
import java.util.function.Supplier;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Все обращения к сервису «Библиотека» по HTTP.
 * Токен метода передаётся в заголовке X-Token. Пользователь на сервисе определяется токеном метода orders.
 */
@Component
public class LibraryApiClient {

    /** TODO: название заголовка должно совпадать с сервисом (SecurityConstants.TOKEN_HEADER). */
    private static final String TOKEN_HEADER = "X-Token";

    private static final Pattern MESSAGE = Pattern.compile("\"message\"\\s*:\\s*\"([^\"]*)\"");
    private static final Pattern ERROR = Pattern.compile("\"error\"\\s*:\\s*\"([^\"]*)\"");

    private final ApiSettings settings;
    private final JdkClientHttpRequestFactory requestFactory;

    public LibraryApiClient(ApiSettings settings) {
        this.settings = settings;
        // HTTP/1.1 принудительно: надёжнее для запросов с телом к Tomcat
        HttpClient http = HttpClient.newBuilder()
                .version(HttpClient.Version.HTTP_1_1)
                .connectTimeout(Duration.ofSeconds(3))
                .build();
        this.requestFactory = new JdkClientHttpRequestFactory(http);
        this.requestFactory.setReadTimeout(Duration.ofSeconds(10));
    }

    private RestClient client(String baseUrl) {
        return RestClient.builder().baseUrl(baseUrl).requestFactory(requestFactory).build();
    }

    private RestClient client() {
        return client(settings.getBaseUrl());
    }

    // ===================== проверка связи =====================

    /** Открытый адрес Swagger-описания (токен не нужен). */
    public boolean ping(String baseUrl) {
        try {
            client(baseUrl).get().uri("/v3/api-docs").retrieve().toBodilessEntity();
            return true;
        } catch (RestClientException e) {
            return false;
        }
    }

    // ===================== метод catalog =====================

    public List<LibraryDto> libraries(String token) {
        List<LibraryDto> result = execute(() -> client().get()
                .uri("/api/catalog/libraries")
                .header(TOKEN_HEADER, token)
                .retrieve()
                .body(new ParameterizedTypeReference<List<LibraryDto>>() {
                }));
        return result == null ? List.of() : result;
    }

    /** Поиск книг. Пустые фильтры означают «без фильтра». */
    public List<BookDto> books(String token, String title, String author, String genre) {
        List<BookDto> result = execute(() -> client().get()
                .uri("/api/catalog/books?title={t}&author={a}&genre={g}", nz(title), nz(author), nz(genre))
                .header(TOKEN_HEADER, token)
                .retrieve()
                .body(new ParameterizedTypeReference<List<BookDto>>() {
                }));
        return result == null ? List.of() : result;
    }

    public BookDto book(String token, Long id) {
        return execute(() -> client().get()
                .uri("/api/catalog/books/{id}", id)
                .header(TOKEN_HEADER, token)
                .retrieve()
                .body(BookDto.class));
    }

    public BookDto createBook(String token, BookRequest request) {
        return execute(() -> client().post()
                .uri("/api/catalog/books")
                .header(TOKEN_HEADER, token)
                .contentType(MediaType.APPLICATION_JSON)
                .body(request)
                .retrieve()
                .body(BookDto.class));
    }

    public BookDto updateBook(String token, Long id, BookRequest request) {
        return execute(() -> client().put()
                .uri("/api/catalog/books/{id}", id)
                .header(TOKEN_HEADER, token)
                .contentType(MediaType.APPLICATION_JSON)
                .body(request)
                .retrieve()
                .body(BookDto.class));
    }

    public void deleteBook(String token, Long id) {
        execute(() -> client().delete()
                .uri("/api/catalog/books/{id}", id)
                .header(TOKEN_HEADER, token)
                .retrieve()
                .toBodilessEntity());
    }

    // ===================== метод orders (заказы токена = заказы читателя) =====================

    public List<OrderDto> orders(String token) {
        List<OrderDto> result = execute(() -> client().get()
                .uri("/api/orders")
                .header(TOKEN_HEADER, token)
                .retrieve()
                .body(new ParameterizedTypeReference<List<OrderDto>>() {
                }));
        return result == null ? List.of() : result;
    }

    public OrderDto order(String token, Long id) {
        return execute(() -> client().get()
                .uri("/api/orders/{id}", id)
                .header(TOKEN_HEADER, token)
                .retrieve()
                .body(OrderDto.class));
    }

    public OrderDto createOrder(String token, OrderRequest request) {
        return execute(() -> client().post()
                .uri("/api/orders")
                .header(TOKEN_HEADER, token)
                .contentType(MediaType.APPLICATION_JSON)
                .body(request)
                .retrieve()
                .body(OrderDto.class));
    }

    public OrderDto updateOrder(String token, Long id, OrderRequest request) {
        return execute(() -> client().put()
                .uri("/api/orders/{id}", id)
                .header(TOKEN_HEADER, token)
                .contentType(MediaType.APPLICATION_JSON)
                .body(request)
                .retrieve()
                .body(OrderDto.class));
    }

    public void deleteOrder(String token, Long id) {
        execute(() -> client().delete()
                .uri("/api/orders/{id}", id)
                .header(TOKEN_HEADER, token)
                .retrieve()
                .toBodilessEntity());
    }

    // ===================== общее =====================

    private <T> T execute(Supplier<T> action) {
        try {
            return action.get();
        } catch (RestClientResponseException e) {
            int status = e.getStatusCode().value();
            throw new ApiException(status, describe(status, serverMessage(e.getResponseBodyAsString())));
        } catch (ResourceAccessException e) {
            throw new ApiException(0, "Сервис недоступен (" + settings.getBaseUrl() + "). Проверьте адрес в блоке "
                    + "«Подключение к сервису», что сервис запущен и что сеть/файрвол пропускают порт.");
        } catch (RestClientException e) {
            throw new ApiException(500, "Неожиданный ответ сервиса: " + e.getMessage());
        }
    }

    private static String serverMessage(String body) {
        if (body == null) return "";
        Matcher m = MESSAGE.matcher(body);
        if (m.find() && !m.group(1).isBlank()) return m.group(1);
        m = ERROR.matcher(body);
        return m.find() ? m.group(1) : "";
    }

    /** Понятное сообщение для пользователя по коду ответа сервиса. */
    private static String describe(int status, String serverMessage) {
        String extra = serverMessage.isBlank() ? "" : " (" + serverMessage + ")";
        return switch (status) {
            case 400 -> "Некорректные данные" + extra;
            case 401 -> "Токен недействителен или выдан на другой метод. Проверьте токен в блоке «Токены оплаты».";
            case 403 -> "Срок действия токена истёк. Оплатите метод заново и введите новый токен.";
            case 404 -> "Не найдено" + extra;
            case 409 -> serverMessage.isBlank() ? "Конфликт данных" : serverMessage;
            case 503 -> "Сервис оплаты недоступен, токен проверить не удалось. Повторите позже.";
            default -> "Ошибка " + status + extra;
        };
    }

    private static String nz(String s) {
        return s == null ? "" : s.trim();
    }
}
