package com.example.libraryclient.dto;

/** Тело запроса на создание / изменение заказа. status при создании не нужен (null). */
public record OrderRequest(Long bookId, String readerName, String readerPhone,
                           String returnDate, String status) {
}
