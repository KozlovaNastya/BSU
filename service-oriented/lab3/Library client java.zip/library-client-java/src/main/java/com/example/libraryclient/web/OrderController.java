package com.example.libraryclient.web;

import com.example.libraryclient.api.ApiException;
import com.example.libraryclient.api.LibraryApiClient;
import com.example.libraryclient.dto.BookDto;
import com.example.libraryclient.dto.OrderDto;
import com.example.libraryclient.dto.OrderRequest;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDate;
import java.util.Map;

import static com.example.libraryclient.web.HomeController.flash;

/** Заказ книги и управление своими заказами (метод orders). Все заказы - только текущего токена. */
@Controller
public class OrderController {

    private final LibraryApiClient api;

    public OrderController(LibraryApiClient api) {
        this.api = api;
    }

    // ---------------- создание заказа ----------------

    @GetMapping("/orders/new")
    public String newOrderForm(@RequestParam("bookId") Long bookId, HttpSession session,
                               Model model, RedirectAttributes ra) {
        if (SessionTokens.get(session, SessionTokens.ORDERS).isEmpty()) {
            flash(ra, "error", "Чтобы заказать книгу, введите токен «Мои заказы» в блоке «Токены оплаты».");
            return "redirect:/";
        }
        String bookTitle = "Книга №" + bookId;
        String catalogToken = SessionTokens.get(session, SessionTokens.CATALOG);
        if (!catalogToken.isEmpty()) {
            try {
                BookDto book = api.book(catalogToken, bookId);
                bookTitle = book.title() + " - " + book.author();
            } catch (ApiException ignored) {
                // название нужно только для красоты
            }
        }
        fillForm(model, "Заказ книги", "/orders", "Заказать", bookId, bookTitle,
                SessionTokens.profile(session, "name"), SessionTokens.profile(session, "phone"),
                LocalDate.now().plusDays(14).toString());
        return "order-form";
    }

    @PostMapping("/orders")
    public String create(@RequestParam Map<String, String> p, HttpSession session, RedirectAttributes ra) {
        String token = SessionTokens.get(session, SessionTokens.ORDERS);
        Long bookId = null;
        try {
            bookId = Forms.requiredLong(p, "bookId", "Книга");
            String name = Forms.required(p, "readerName", "Ваше имя");
            String phone = Forms.textOrNull(p, "readerPhone");
            String returnDate = checkReturnDate(Forms.textOrNull(p, "returnDate"));

            api.createOrder(token, new OrderRequest(bookId, name, phone, returnDate, null));
            SessionTokens.saveProfile(session, name, phone);
            flash(ra, "ok", "Книга заказана. Заберите её в библиотеке.");
            return "redirect:/";
        } catch (IllegalArgumentException | ApiException e) {
            flash(ra, "error", e.getMessage());
            return bookId == null ? "redirect:/" : "redirect:/orders/new?bookId=" + bookId;
        }
    }

    // ---------------- изменение данных заказа ----------------

    @GetMapping("/orders/{id}/edit")
    public String editForm(@PathVariable("id") Long id, HttpSession session, Model model, RedirectAttributes ra) {
        try {
            OrderDto order = api.order(SessionTokens.get(session, SessionTokens.ORDERS), id);
            fillForm(model, "Изменить заказ №" + id, "/orders/" + id + "/edit", "Сохранить", order.bookId(),
                    "Книга №" + order.bookId(), order.readerName(),
                    order.readerPhone() == null ? "" : order.readerPhone(),
                    order.returnDate() == null ? "" : order.returnDate());
            return "order-form";
        } catch (ApiException e) {
            flash(ra, "error", e.getMessage());
            return "redirect:/";
        }
    }

    @PostMapping("/orders/{id}/edit")
    public String edit(@PathVariable("id") Long id, @RequestParam Map<String, String> p,
                       HttpSession session, RedirectAttributes ra) {
        try {
            String token = SessionTokens.get(session, SessionTokens.ORDERS);
            OrderDto current = api.order(token, id);
            String name = Forms.required(p, "readerName", "Ваше имя");
            String phone = Forms.textOrNull(p, "readerPhone");
            String returnDate = checkReturnDate(Forms.textOrNull(p, "returnDate"));

            api.updateOrder(token, id, new OrderRequest(current.bookId(), name, phone, returnDate, current.status()));
            flash(ra, "ok", "Заказ изменён");
            return "redirect:/";
        } catch (IllegalArgumentException | ApiException e) {
            flash(ra, "error", e.getMessage());
            return "redirect:/orders/" + id + "/edit";
        }
    }

    // ---------------- смена статуса, продление, удаление ----------------

    @PostMapping("/orders/{id}/status")
    public String status(@PathVariable("id") Long id, @RequestParam("status") String status,
                         HttpSession session, RedirectAttributes ra) {
        try {
            String token = SessionTokens.get(session, SessionTokens.ORDERS);
            OrderDto o = api.order(token, id);
            api.updateOrder(token, id, new OrderRequest(o.bookId(), o.readerName(), o.readerPhone(), o.returnDate(), status));
            flash(ra, "ok", switch (status) {
                case "ISSUED" -> "Приятного чтения!";
                case "RETURNED" -> "Книга возвращена, спасибо!";
                case "CANCELLED" -> "Заказ отменён";
                default -> "Заказ обновлён";
            });
        } catch (ApiException e) {
            flash(ra, "error", e.getMessage());
        }
        return "redirect:/";
    }

    @PostMapping("/orders/{id}/extend")
    public String extend(@PathVariable("id") Long id, HttpSession session, RedirectAttributes ra) {
        try {
            String token = SessionTokens.get(session, SessionTokens.ORDERS);
            OrderDto o = api.order(token, id);
            LocalDate base = LocalDate.now();
            if (o.returnDate() != null && LocalDate.parse(o.returnDate()).isAfter(base)) {
                base = LocalDate.parse(o.returnDate());
            }
            api.updateOrder(token, id, new OrderRequest(o.bookId(), o.readerName(), o.readerPhone(),
                    base.plusDays(7).toString(), o.status()));
            flash(ra, "ok", "Срок продлён на 7 дней");
        } catch (ApiException e) {
            flash(ra, "error", e.getMessage());
        }
        return "redirect:/";
    }

    @PostMapping("/orders/{id}/delete")
    public String delete(@PathVariable("id") Long id, HttpSession session, RedirectAttributes ra) {
        try {
            api.deleteOrder(SessionTokens.get(session, SessionTokens.ORDERS), id);
            flash(ra, "ok", "Заказ убран из списка");
        } catch (ApiException e) {
            flash(ra, "error", e.getMessage());
        }
        return "redirect:/";
    }

    // ---------------- вспомогательное ----------------

    private void fillForm(Model model, String heading, String action, String submitText, Long bookId,
                          String bookTitle, String name, String phone, String returnDate) {
        model.addAttribute("heading", heading);
        model.addAttribute("formAction", action);
        model.addAttribute("submitText", submitText);
        model.addAttribute("bookId", bookId);
        model.addAttribute("bookTitle", bookTitle);
        model.addAttribute("name", name);
        model.addAttribute("phone", phone);
        model.addAttribute("returnDate", returnDate);
        model.addAttribute("today", LocalDate.now().toString());
    }

    /** Срок возврата: пусто или корректная дата не в прошлом. */
    private String checkReturnDate(String value) {
        if (value == null) return null;
        LocalDate date;
        try {
            date = LocalDate.parse(value);
        } catch (Exception e) {
            throw new IllegalArgumentException("Некорректная дата возврата");
        }
        if (date.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Срок возврата не может быть в прошлом");
        }
        return value;
    }
}
