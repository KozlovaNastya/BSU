package com.example.libraryclient.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record BookDto(Long id, Long libraryId, String title, String author, String genre,
                      String isbn, Integer year, Integer copiesAvailable) {
}
