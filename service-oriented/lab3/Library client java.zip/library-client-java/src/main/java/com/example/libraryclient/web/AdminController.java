package com.example.libraryclient.web;

import com.example.libraryclient.api.ApiException;
import com.example.libraryclient.api.LibraryApiClient;
import com.example.libraryclient.config.ApiSettings;
import com.example.libraryclient.dto.BookDto;
import com.example.libraryclient.dto.BookRequest;
import com.example.libraryclient.dto.LibraryDto;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Map;

import static com.example.libraryclient.web.HomeController.flash;

/**
 * Страница библиотекаря: управление каталогом (метод catalog).
 * Таблица книг: поля редактируются прямо в строке, есть удаление и добавление.
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

    private final LibraryApiClient api;
    private final ApiSettings settings;

    public AdminController(LibraryApiClient api, ApiSettings settings) {
        this.api = api;
        this.settings = settings;
    }

    @GetMapping
    public String page(@RequestParam(name = "title", defaultValue = "") String title,
                       @RequestParam(name = "author", defaultValue = "") String author,
                       @RequestParam(name = "genre", defaultValue = "") String genre,
                       HttpSession session, Model model) {
        String token = SessionTokens.get(session, SessionTokens.CATALOG);
        model.addAttribute("catalogToken", token);
        model.addAttribute("hasCatalogToken", !token.isEmpty());
        model.addAttribute("qTitle", title);
        model.addAttribute("qAuthor", author);
        model.addAttribute("qGenre", genre);
        model.addAttribute("serviceUrl", settings.getBaseUrl());

        List<BookDto> books = List.of();
        List<LibraryDto> libraries = List.of();
        String error = null;
        if (!token.isEmpty()) {
            try {
                libraries = api.libraries(token);
                books = api.books(token, title, author, genre);
            } catch (ApiException e) {
                error = e.getMessage();
            }
        }
        model.addAttribute("books", books);
        model.addAttribute("libraries", libraries);
        model.addAttribute("catalogError", error);
        return "admin";
    }

    @PostMapping("/books")
    public String create(@RequestParam Map<String, String> p, HttpSession session, RedirectAttributes ra) {
        try {
            api.createBook(SessionTokens.get(session, SessionTokens.CATALOG), parse(p));
            flash(ra, "ok", "Книга добавлена");
        } catch (IllegalArgumentException | ApiException e) {
            flash(ra, "error", e.getMessage());
        }
        return "redirect:/admin";
    }

    @PostMapping("/books/{id}")
    public String update(@PathVariable("id") Long id, @RequestParam Map<String, String> p,
                         HttpSession session, RedirectAttributes ra) {
        try {
            api.updateBook(SessionTokens.get(session, SessionTokens.CATALOG), id, parse(p));
            flash(ra, "ok", "Книга №" + id + " сохранена");
        } catch (IllegalArgumentException | ApiException e) {
            flash(ra, "error", e.getMessage());
        }
        return "redirect:/admin";
    }

    @PostMapping("/books/{id}/delete")
    public String delete(@PathVariable("id") Long id, HttpSession session, RedirectAttributes ra) {
        try {
            api.deleteBook(SessionTokens.get(session, SessionTokens.CATALOG), id);
            flash(ra, "ok", "Книга №" + id + " удалена");
        } catch (ApiException e) {
            flash(ra, "error", e.getMessage());
        }
        return "redirect:/admin";
    }

    private BookRequest parse(Map<String, String> p) {
        Long libraryId = Forms.requiredLong(p, "libraryId", "Библиотека");
        String title = Forms.required(p, "title", "Название");
        String author = Forms.required(p, "author", "Автор");
        Integer copies = Forms.intOrNull(p, "copiesAvailable", "Экземпляров");
        if (copies == null || copies < 0) {
            throw new IllegalArgumentException("Количество экземпляров должно быть целым числом, не меньше 0");
        }
        return new BookRequest(libraryId, title, author, Forms.textOrNull(p, "genre"),
                Forms.textOrNull(p, "isbn"), Forms.intOrNull(p, "year", "Год"), copies);
    }
}
